<?php

$conn = mysqli_connect('localhost','root','','flower_shop_db') or die('connection failed');

?>