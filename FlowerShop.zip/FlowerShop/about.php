<?php

@include 'config.php';

session_start();

$user_id = $_SESSION['user_id'];

if(!isset($user_id)){
   header('location:login.php');
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>about</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom admin css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<?php @include 'header.php'; ?>

<section class="heading">
    <h3>about us</h3>
    <p> <a href="home.php">home</a> / about us </p>
</section>

<section class="about">

    <div class="flex">

        <div class="image">
            <img src="images/about-img-1.jpeg" alt="">
        </div>

        <div class="content">
            <h3>why choose us?</h3>
            <p></li><strong>Freshness Guaranteed:</strong> We source the freshest flowers from trusted suppliers to ensure longevity and vibrant beauty in every arrangement.</li></br>
            </li><strong>Customized Arrangements:</strong> Our skilled florists work with you to create bespoke bouquets and arrangements tailored to your preferences and occasions.</li></br>
            </li><strong>Exceptional Customer Service:</strong> We pride ourselves on providing a friendly, personalized shopping experience, whether you're visiting our shop or ordering online.</li></br>
            </li><strong>Wide Variety:</strong> From classic roses to exotic orchids, we offer a diverse selection of flowers to suit all tastes and events.</li></p>
            <a href="shop.php" class="btn">shop now</a>
        </div>

    </div>

    <div class="flex">

        <div class="content">
            <h3>what we provide?</h3>
            <p></li><strong>Fresh Flower Bouquets:</strong> Handcrafted bouquets using the freshest blooms, perfect for any celebration or to brighten someone's day.</li></br>
            </li><strong>Custom Floral Arrangements:</strong> Tailored floral designs to suit your specific needs and preferences, ideal for weddings, events, and special occasions.</li></br>
            </li><strong>Seasonal Flowers:</strong> A rotating selection of seasonal flowers, ensuring the best blooms year-round.</li></br>
            </li><strong>Sympathy Flowers:</strong> Thoughtfully designed arrangements to express your condolences and support during difficult times.</li></p>
            <a href="contact.php" class="btn">contact us</a>
        </div>

        <div class="image">
            <img src="images/about-img-2.jpg" alt="">
        </div>

    </div>

    <div class="flex">

        <div class="image">
            <img src="images/about-img-4.jpg" alt="">
        </div>

        <div class="content">
            <h3>who we are?</h3>
            <p>Founded in 2024, Bloom&Blossoms has been dedicated to providing beautiful floral arrangements and exceptional customer service. Our team of skilled florists brings creativity, passion, and a keen eye for detail to every bouquet and floral design.</p>
            <p>We source the freshest flowers from local growers and trusted suppliers to ensure that every arrangement is of the highest quality. Our commitment to excellence and our love for flowers drive us to constantly innovate and create stunning designs that bring joy to our customers.</p>
            <p>At Bloom&Blossoms, we believe that flowers are more than just decorations—they are expressions of love, celebration, and comfort. We are honored to be a part of your special moments and strive to make each one unforgettable.</p>
            <a href="#reviews" class="btn">clients reviews</a>
        </div>

    </div>

</section>

<section class="reviews" id="reviews">

    <h1 class="title">client's reviews</h1>

    <div class="box-container">

        <div class="box">
            <img src="images/pic-1.jpg" alt="">
            <p>"Amazing customer service and quick delivery. The flowers looked very beautiful. Will order again!"</p>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>
            <h3>Michael T.</h3>
        </div>

        <div class="box">
            <img src="images/pic-2.png" alt="">
            <p>"Absolutely stunning bouquets! The flowers arrived fresh and beautifully arranged. Highly recommend!"</p>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>
            <h3>Sarah L.</h3>
        </div>

        <div class="box">
            <img src="images/pic-3.png" alt="">
            <p>"The flowers were gorgeous and lasted a long time. Very happy with my purchase."</p>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>
            <h3>Daniel K.</h3>
        </div>

        <div class="box">
            <img src="images/pic-4.png" alt="">
            <p>"Great selection and easy to order online. My mom loved her birthday flowers. Thank you!" </p>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>
            <h3>Emily R.</h3>
        </div>

        <div class="box">
            <img src="images/pic-5.png" alt="">
            <p>"Prompt delivery and the flowers were perfect. Made my anniversary special. Thank you!"</p>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>
            <h3>Frank G.</h3>
        </div>

        <div class="box">
            <img src="images/pic-6.jpeg" alt="">
            <p>"Beautiful arrangements and excellent quality. The online ordering process was a breeze!"</p>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>
            <h3>Laura K.</h3>
        </div>

    </div>

</section>











<?php @include 'footer.php'; ?>

<script src="js/script.js"></script>

</body>
</html>